namespace CODE.Models
{
    public class Department
    {
        public int Id { get; set; }
        public string DeptName { get; set; }
    }
}
