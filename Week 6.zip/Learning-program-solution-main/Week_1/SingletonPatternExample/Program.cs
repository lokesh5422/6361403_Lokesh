﻿using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Testing Singleton Pattern...");
        LoggerTest.RunTest();
    }
}
