﻿namespace CustomerCommLib;

public class Class1
{

}
